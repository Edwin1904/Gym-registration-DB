/* create database NCU Gym Registration Management System*/

drop database if exists NCU_GRMS;
create database NCU_GRMS;

/* select  as main database and create tables */

use NCU_GRMS;

-- CREATE TABLES

CREATE TABLE GYM (
GYM_NAME	VARCHAR(30)		NOT NULL DEFAULT 'NCU FITNESS CENTRE',
Street 		Varchar(20)		Not Null default 'Manchester Rd',
Town		Varchar(20)		NOT NULL DEFAULT 'Mandeville',
Parish		Varchar(20)		NOT NULL DEFAULT 'Manchester',
Country		VARCHAR(20)		NOT NULL DEFAULT 'Jamaica',
PRIMARY KEY (GYM_NAME)
);

CREATE TABLE STUDENT(
STUDENT_ID				VARCHAR(8) 		NOT NULL UNIQUE,
LNAME					VARCHAR(20) 	NOT NULL,
FNAME					VARCHAR(20)		NOT NULL,
DOB						DATE 			NOT NULL,
SEX						VARCHAR(1)		NOT NULL,
MED_CONDITION			VARCHAR(20)	,
EMAIL					VARCHAR(50) 	NOT NULL,
PHONE					VARCHAR(10)	,
MAJOR					VARCHAR(30) 	NOT NULL,
HEIGHT_in_inc 			NUMERIC(3,1)	NOT NULL,
WEIGHT_in_lbs			NUMERIC(3)		NOT NULL,
NECK					NUMERIC(3,1) 	NOT NULL,
CHEST					NUMERIC(3,1) 	NOT NULL,
WAIST					NUMERIC(3,1) 	NOT NULL,
HIP						NUMERIC(3,1) 	NOT NULL,
UPPERARM				NUMERIC(3,1) 	NOT NULL,
FOREARM					NUMERIC(3,1) 	NOT NULL,
WRIST					NUMERIC(3,1) 	NOT NULL,
THIGH					NUMERIC(3,1) 	NOT NULL,
CALF					NUMERIC(3,1) 	NOT NULL,
CHOSENDAY1				VARCHAR(10),
CHOSENDAY2				VARCHAR(10),
CHOSENDAY3				VARCHAR(10),
CHOSENDAY4				VARCHAR(10),
CHOSENDAY5				VARCHAR(10),
CHOSENTIME1				TIME,	
CHOSENTIME2				TIME,	
CHOSENTIME3				TIME,	
CHOSENTIME4				TIME,	
CHOSENTIME5				TIME,	
PRIMARY KEY (STUDENT_ID)	
);

CREATE TABLE STAFF(
STAFF_ID			VARCHAR(8) 		NOT NULL UNIQUE,
LNAME				VARCHAR(20) 	NOT NULL,
FNAME				VARCHAR(20)		NOT NULL,
DOB					DATE 			NOT NULL,
SEX					VARCHAR(1)		NOT NULL,
MED_CONDITION		VARCHAR(20),
EMAIL				VARCHAR(50) 	NOT NULL,
PHONE				VARCHAR(10),
JOB_CLASS			VARCHAR(30) 	NOT NULL,
HEIGHT_in_inc	 	NUMERIC(3,1)	NOT NULL,
WEIGHT_in_lbs		NUMERIC(3)		NOT NULL,
NECK				NUMERIC(3,1) 	NOT NULL,
CHEST				NUMERIC(3,1) 	NOT NULL,
WAIST				NUMERIC(3,1) 	NOT NULL,
HIP					NUMERIC(3,1) 	NOT NULL,
UPPERARM			NUMERIC(3,1) 	NOT NULL,
FOREARM				NUMERIC(3,1) 	NOT NULL,
WRIST				NUMERIC(3,1) 	NOT NULL,
THIGH				NUMERIC(3,1) 	NOT NULL,
CALF				NUMERIC(3,1) 	NOT NULL,
CHOSENDAY1			VARCHAR(10),
CHOSENDAY2			VARCHAR(10),
CHOSENDAY3			VARCHAR(10),
CHOSENDAY4			VARCHAR(10),
CHOSENDAY5			VARCHAR(10),
CHOSENTIME1			TIME,	
CHOSENTIME2			TIME,	
CHOSENTIME3			TIME,	
CHOSENTIME4			TIME,	
CHOSENTIME5			TIME,	
PRIMARY KEY (STAFF_ID)	
);

CREATE TABLE GYM_EMPLOYEES (
GYMEMP_ID			VARCHAR(8)	NOT NULL UNIQUE,
GYMEMP_LMAME		VARCHAR(20)	NOT NULL,
GYMEMP_FMAME		VARCHAR(20) NOT NULL,
GYMEMP_JOB_CLASS	VARCHAR(10)	NOT NULL,
GYM_NAME	VARCHAR(30) NOT NULL,
PRIMARY KEY (GYMEMP_ID),
FOREIGN KEY (GYM_NAME) REFERENCES GYM(GYM_NAME)
);

CREATE TABLE PROGRAMMES (
PROGRAMME_ID	VARCHAR(3) 	NOT NULL UNIQUE,
PROGRAMME_NAME	VARCHAR(15) NOT NULL,
TRAINER_ID		VARCHAR(8)	,
PRIMARY KEY (PROGRAMME_ID),
FOREIGN KEY (TRAINER_ID) REFERENCES GYM_EMPLOYEES(GYMEMP_ID)
);

CREATE TABLE GYM_MEMBERSHIP (
MEMBER_ID		INT(4) 		NOT NULL AUTO_INCREMENT,
STUDENT_ID		VARCHAR(8) 	UNIQUE,
STAFF_ID		VARCHAR(8) 	UNIQUE,
PROGRAMME_ID 	VARCHAR(3) 	NOT NULL,
GYM_NAME		VARCHAR(30) NOT NULL,
PRIMARY KEY (MEMBER_ID), 
FOREIGN KEY (STUDENT_ID) REFERENCES STUDENT(STUDENT_ID),
FOREIGN KEY (STAFF_ID) REFERENCES STAFF(STAFF_ID),
FOREIGN KEY (GYM_NAME) REFERENCES GYM(GYM_NAME),
FOREIGN KEY (PROGRAMME_ID) REFERENCES PROGRAMMES(PROGRAMME_ID)
);



-- Insert Data into Tables

Insert into Gym values(Default,default,default,default,default);

insert into STUDENT Values 
	('20172562','Kemp','Ajani','1999-11-30','M','Asthma','akemp@stu.ncu.edu.jm','348-6264','Computer Science',73,145,15,35,30.5,37.5,10.2,10,6.2,19.2,13.2,'Monday','Wednesday','Friday',NULL,NULL,'20:00:00','20:00:00','08:00:00',NULL,NULL),
    ('20171291','Scott','Christopher','1996-01-28','M','Back Pain','cscott13@stu.ncu.edu.jm','348-6264','Computer Science',69,200,17.1,41,36,45,14.5,12,7,24,15.5,'Monday','Wednesday','Thursday',NULL,NULL,'18:00:00','18:00:00','19:00:00',NULL,NULL),
    ('20171135','Miller','Edwin','1999-04-19','M','None','emiller@stu.ncu.edu.jm','348-6264','Computer Science',71,155,14.5,34,30,34,9.1,9.2,6.3,16.5,12.3,'Monday','Tuesday','Thursday',NULL,NULL,'17:00:00','18:00:00','17:00:00',NULL,NULL),
    ('20172561','Franklin','Alrick','2000-09-21','M','None','afrankin@stu.ncu.edu.jm','348-6264','Information Technology',67,130,15.6,35,29,35.3,10.3,10,6.4,19.2,14,'Monday','Tuesday','Wednesday',NULL,NULL,'16:00:00','20:00:00','18:00:00',NULL,NULL),
    ('20163225','Some','Akid','1997-10-24','F','Diabetes','skid@stu.ncu.edu.jm','423-7173','Psychology',73,150,14.4,33.1,30.1,34.5,10,9.5,6.4,20.4,13.3,'Monday','Tuesday','Wednesday','Thursday','Friday','06:00:00','06:00:00','06:00:00','06:00:00','06:00:00'),
    ('20175226','Lenora','Evay','1998-02-13','F','Arrhythmia','levay@stu.ncu.edu.jm','211-2234','Mathematics',68.8,146,14.2,34.1,28.5,34.5,10,10.2,7,19.1,13,'Monday','Wednesday','Thursday',NULL,NULL,'20:00:00','20:00:00','20:00:00',NULL,NULL);
    																																
                                                                                                                                    
insert into STAFF values
	('82832484','Bianca',	'Atassa',	'1990-10-17','F',	'None',			'tbianca@ncu.edu.jm',	'739-9289','Accountant',69.8,170,17.1,48.5,48,44,16,13.5,8,27,19,'Monday','Tuesday','Thursday',NULL,NULL,'05:00:00','05:00:00','05:00:00',NULL,NULL),
	('51543542','Arevalo',	'Hugo',		'1992-01-10','M',	'Joint Pain',	'harevalo@ncu.edu.jm',	'692-6198','Professor',68.6,210,15.2,41.5,36,45.5,12,10.7,7,20,13.4,'Monday','Tuesday','Wednesday','Friday',NULL,'16:00:00','16:00:00','16:00:00','07:00:00',NULL),
    ('76728668','Alonzo',	'Daniel',	'1990-04-5','M',	'Diabetes',		'dalonzo@ncu.edu.jm',	'645-8187','Professor',70.5,230,14.2,34.5,28,36.6,10.1,10.2,6.8,20,14.2,'Monday','Wednesday','Friday',NULL,NULL,'06:00:00','06:00:00','06:00:00',NULL,NULL),
	('83721933','Thurman',	'Stacy',	'1989-11-30','F',	'None',			'sthurman@ncu.edu.jm',	'230-2533','Counselor',63,120,17.1,41.1,40,48,13.4,12.6,7.4,29.6,17.5,'Tuesday','Friday',NULL,NULL,NULL,'16:00:00','07:00:00',NULL,NULL,NULL),
	('79713894','Natasha','Silvanus',	'1994-02-12','M',	'None',			'snatasha@ncu.edu.jm',	'552-6322','IT Technician',76,197,16.1,40.1,36,44.6,12.5,11.2,7,29,15.9,'Monday','Wednesday','Friday',NULL,NULL,'07:00:00','07:00:00','07:00:00',NULL,NULL);
    
    
insert into GYM_EMPLOYEES values
	('32335156','Mendoza','Iqra','Trainer','NCU FITNESS CENTRE'),
    ('28699593','Yasmin','Zainab','Trainer','NCU FITNESS CENTRE'),
    ('62078610','Telsa','Betty','Trainer','NCU FITNESS CENTRE'),
    ('56230644','Jax','Ivan','Trainer','NCU FITNESS CENTRE'),
    ('34167509','Sashenka','Alexander','Manager','NCU FITNESS CENTRE');
    
    
insert into PROGRAMMES values
	('120','Toning','32335156'),
    ('121','Bulking','28699593'),
    ('122','Weight Loss','62078610'),
    ('123','Athletic','56230644'),
    ('124','Independent',NULL);
    
    
ALTER TABLE GYM_MEMBERSHIP AUTO_INCREMENT=1000;
insert into GYM_MEMBERSHIP (STUDENT_ID, STAFF_ID, PROGRAMME_ID,GYM_NAME) VALUES
	('20172562', NULL,'121','NCU FITNESS CENTRE'),
	('20171135',NULL,'123','NCU FITNESS CENTRE'),
    ('20171291',NULL,'122','NCU FITNESS CENTRE'),
    ('20172561',NULL,'121','NCU FITNESS CENTRE'),   
	('20163225',NULL,'121','NCU FITNESS CENTRE'),
    ('20175226',NULL,'120','NCU FITNESS CENTRE'),
    (NULL,'82832484','122','NCU FITNESS CENTRE'),
    (NULL,'51543542','122','NCU FITNESS CENTRE'),
    (NULL,'76728668','124','NCU FITNESS CENTRE'),
    (NULL,'83721933','123','NCU FITNESS CENTRE'),
    (NULL,'79713894','123','NCU FITNESS CENTRE');

	

-- Show tables

	
    select * from STUDENT;
    select * from STAFF;
    select * from GYM_MEMBERSHIP;
    select * from GYM;
    select * from GYM_EMPLOYEES;
    select * from PROGRAMMES;
    
    
-- queries 

 -- ALL STUDENTS THAT ARE IN THE BULKING PROGRAMME
SELECT STUDENT.FNAME,STUDENT.LNAME FROM STUDENT,GYM_MEMBERSHIP
WHERE (GYM_MEMBERSHIP.PROGRAMME_ID="121" AND GYM_MEMBERSHIP.STUDENT_ID=STUDENT.STUDENT_ID);

 
-- number of female staff who do toning
select count(PROGRAMME_ID) AS "FEMALES WHO TONE MUSCLE" FROM PROGRAMMES,STAFF
WHERE PROGRAMME_ID='120' AND SEX='F';


-- BMI and Names of all the teachers sorted by BMI (HIGHEST TO LOWEST)
select ROUND((WEIGHT_in_lbs/Pow(Height_in_inc,2)*703),1) AS BMI ,FNAME AS "FIRST NAME",LNAME AS "LAST NAME" 
FROM STAFF
ORDER by BMI DESC;


-- BMI and names of all students sorted by BMI (LOWEST TO HIGHEST)
select ROUND((WEIGHT_in_lbs/Pow(Height_in_inc,2)*703),1) AS BMI, FNAME AS "FIRST NAME", LNAME AS "LAST NAME" 
FROM STUDENT
ORDER by BMI ASC;


-- Average BMI of all students of the gym
SELECT ROUND(AVG((WEIGHT_in_lbs/Pow(Height_in_inc,2)*703)),1) AS "AVERAGE BMI" 
FROM STUDENT;


 -- select ids, names, major, sex and phone numbers of computer science majors or female students
 select STUDENT_ID,FNAME, LNAME, PHONE, MAJOR, SEX FROM STUDENT
 where MAJOR='Computer Science' OR SEX='F';

 
 -- Alter table add column school to student 
ALTER TABLE STUDENT
ADD SCHOOL VARCHAR(35);

-- Check that its been done 
describe student;

-- Update school of all students to Northern Caribbean University
UPDATE STUDENT 
SET SCHOOL = 'Northern Caribbean University'
WHERE STUDENT_ID LIKE '201%';

-- Check 
select * from STUDENT;


-- Names of all overweight, underweight and obese students
SELECT FNAME, LNAME, ROUND((WEIGHT_in_lbs/Pow(Height_in_inc,2)*703),1) AS BMI 
FROM STUDENT 
WHERE (WEIGHT_in_lbs/Pow(Height_in_inc,2)*703)>25 OR (WEIGHT_in_lbs/Pow(Height_in_inc,2)*703)< 18.5;


-- names of all overweight, underweight and obese staff
SELECT FNAME, LNAME, ROUND((WEIGHT_in_lbs/Pow(Height_in_inc,2)*703),1) AS BMI 
FROM Staff
WHERE (WEIGHT_in_lbs/Pow(Height_in_inc,2)*703)>25 OR (WEIGHT_in_lbs/Pow(Height_in_inc,2)*703)< 18.5; 


-- names of Students with a healthy weight 
SELECT FNAME AS 'FIRST NAME', LNAME AS 'LAST NAME', ROUND((WEIGHT_in_lbs/Pow(Height_in_inc,2)*703),1) AS BMI 
FROM STUDENT
WHERE (WEIGHT_in_lbs/Pow(Height_in_inc,2)*703) BETWEEN 18.5 AND 24;


-- names of Staff with a healthy weight 
SELECT FNAME, LNAME, ROUND((WEIGHT_in_lbs/Pow(Height_in_inc,2)*703),1) AS BMI 
FROM Staff
WHERE (WEIGHT_in_lbs/Pow(Height_in_inc,2)*703) BETWEEN 18.5 AND 24; 


-- names and programmes of all people whose first name starts with "A" that are female
SELECT STUDENT.STUDENT_ID,STUDENT.FNAME AS "STUDENT FIRST NAME",STUDENT.LNAME AS "STUDENT LAST NAME",GYM_MEMBERSHIP.PROGRAMME_ID,PROGRAMMES.PROGRAMME_NAME FROM STUDENT,GYM_MEMBERSHIP,PROGRAMMES  
WHERE (STUDENT.FNAME LIKE 'A%' AND STUDENT.SEX = 'F')
GROUP BY STUDENT.STUDENT_ID;


-- NAMES OF STUDENTS WITH A CALF SIZE BETWEEN 14 AND 16 INCHES
SELECT FNAME, LNAME FROM STUDENT 
WHERE CALF IN (SELECT CALF FROM STUDENT WHERE CALF BETWEEN 14 AND 16);
